
#include <DHT.h>
#include <WiFi.h>
#include <ThingSpeak.h>

// WiFi Configuration
const char* WIFI_Name = "Wokwi-GUEST";
const char* WIFI_Pass = "";

// ThingSpeak Configuration
const int channelNumber = 3561184;
const char* apikey = "08SEF9OOQCLBZ17Y";

// WiFi Client
WiFiClient clientobject;

// DHT Sensor
DHT sensorDHT(17, DHT22);

void setup() {
  Serial.begin(115200);

  // Initialize DHT Sensor
  sensorDHT.begin();

  // Connect to WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_Name, WIFI_Pass);

  while (WiFi.status() != WL_CONNECTED) {
    Serial.println("Status: Not Connected");
    delay(1000);
  }

  Serial.println("Status: Connected");
  Serial.println("Student ID: 12323406");

  // Initialize ThingSpeak
  ThingSpeak.begin(clientobject);
}

void loop() {

  // Read Temperature and Humidity
  float temperature = sensorDHT.readTemperature();
  float humidity = sensorDHT.readHumidity();

  // Print Sensor Values
  Serial.print("Temperature: ");
  Serial.println(temperature);

  Serial.print("Humidity: ");
  Serial.println(humidity);

  // Check Sensor Readings
  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read from DHT sensor!");
    delay(20000);
    return;
  }

  // Set ThingSpeak Fields
  ThingSpeak.setField(1, temperature);
  ThingSpeak.setField(2, humidity);

  // Send Data to ThingSpeak
  int stat = ThingSpeak.writeFields(channelNumber, apikey);

  if (stat == 200) {
    Serial.println("Data Sent to ThingSpeak");
  } else {
    Serial.print("Problem Sending Data. HTTP Error: ");
    Serial.println(stat);
  }

  // Wait 20 Seconds
  delay(20000);
}